window.onscroll = function() {
    const scrollToTopBtn = document.getElementById("scrollToTopBtn");
    
    
    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
      scrollToTopBtn.style.display = "block";
    } else {
      scrollToTopBtn.style.display = "none"; 
    }
  };
  document.getElementById("scrollToTopBtn").addEventListener("click", function() {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  });
  function startCountdown() {
    const endTime = new Date().getTime() + 3600 * 1000; 
    const countdownElement = document.getElementById('countdown');
  
    const interval = setInterval(function() {
      const now = new Date().getTime();
      const timeRemaining = endTime - now;
  
      if (timeRemaining <= 0) {
        clearInterval(interval);
        countdownElement.innerHTML = "A promoção acabou!";
      } else {
        const hours = Math.floor(timeRemaining / (1000 * 60 * 60));
        const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);
  
        countdownElement.innerHTML = `${hours}h ${minutes}m ${seconds}s`;
      }
    }, 1000);
  }
  
  
  window.addEventListener('load', startCountdown);

  let currentTestimonial = 0;

function showTestimonials() {
  const testimonials = document.querySelectorAll('.testimonial');
  testimonials.forEach((testimonial, index) => {
    testimonial.style.display = (index === currentTestimonial) ? 'block' : 'none';
  });

  currentTestimonial = (currentTestimonial + 1) % testimonials.length;
}

window.addEventListener('load', function() {
  showTestimonials();
  setInterval(showTestimonials, 3000); 
});
function cadastro(){
    alert('Mensagem enviada para o suporte, temos 1 ano para te retornar');
  }
  